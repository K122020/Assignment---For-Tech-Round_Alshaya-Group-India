package org.alshaya.pages;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class AccountPage {
	private WebDriver driver;
	WebDriverWait wait;
	
	private final By successMsg = By.xpath("//div[@data-ui-id='message-success']/div");
	private final By dropDown = By.xpath("(//*[@data-action='customer-menu-toggle'])[1]");
	private final By singOut = By.xpath("(//a[normalize-space()='Sign Out'])[1]");
	private final By successMsgForSignOut = By.xpath("//*[@data-ui-id='page-title-wrapper']");
	
	
	public AccountPage(WebDriver driver) {
		this.driver = driver;
		wait = new WebDriverWait(driver, Duration.ofSeconds(60));
	}
	
	public String checkSuccessMessage() {
		return wait.until(ExpectedConditions.visibilityOfElementLocated(successMsg)).getText();
		
	}
	
	public AccountPage clickOndropDownOption() {
		
		driver.findElement(dropDown).click();
		return new AccountPage(driver);
	}
public AccountPage clickOnSingOutOption() {
		
		driver.findElement(singOut).click();
		return new AccountPage(driver);
	}

public String validateSignOut() {
	
	return wait.until(ExpectedConditions.visibilityOfElementLocated(successMsgForSignOut)).getText();
}

public String validatreAccountHeading() {
	return wait.until(ExpectedConditions.visibilityOfElementLocated(successMsgForSignOut)).getText();
	
}

}
