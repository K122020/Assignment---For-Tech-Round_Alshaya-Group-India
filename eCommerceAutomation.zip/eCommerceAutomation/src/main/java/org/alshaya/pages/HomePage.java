package org.alshaya.pages;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class HomePage {
	private WebDriver driver;
	WebDriverWait wait;
	
	private final By createAnAccount = By.xpath("(//a[text()='Create an Account'])[1]");
	private final By signIn = By.xpath("(//a[contains(text(),'Sign In')])[1]");
	private final By menuOption = By.xpath("//nav[@class='navigation']/ul/li[4]");
	private final By category = By.xpath("//a[contains(text(),'Bags')]");
	
	public HomePage(WebDriver driver) {
		this.driver = driver;
		wait = new WebDriverWait(driver, Duration.ofSeconds(60));
	}
	
	public RegisterationPage clickOnCreateAnAccountMenuOption() {
		wait.until(ExpectedConditions.visibilityOfElementLocated(createAnAccount)).click();
		return new RegisterationPage(driver);
	}
	
	public SignInPage clickOnSignInMenuOption() {
		wait.until(ExpectedConditions.visibilityOfElementLocated(signIn)).click();
		return new SignInPage(driver);
	}
	
	public void clickOnMainMenu() {
		wait.until(ExpectedConditions.visibilityOfElementLocated(menuOption)).click();
	
	}
	
	public void clickOnCategory() {
		wait.until(ExpectedConditions.visibilityOfElementLocated(category)).click();
	}
//	public void blockPopup() {
//		JavascriptExecutor js = (JavascriptExecutor) driver;
//		js.executeScript("document.querySelector('.horizontal.loaded').remove();");
//	}
}
