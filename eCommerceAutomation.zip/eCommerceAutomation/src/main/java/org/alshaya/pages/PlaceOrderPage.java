package org.alshaya.pages;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.ElementClickInterceptedException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class PlaceOrderPage {
	private WebDriver driver;
	WebDriverWait wait;
	
	private final By paymentMethodHeading = By.xpath("//div[@class='step-title' and @data-role='title' and text()='Payment Method']");
	private final By placeOrder = By.xpath("//button[@title='Place Order' and contains(@class, 'action primary checkout')]");
	private final By checkboxLabel = By.xpath("//span[text()='My billing and shipping address are the same']");
	private final By checkbox = By.xpath("//input[starts-with(@id, 'billing-address-same-as-shipping-') and contains(@id, 'checkmo')]");
	private final By placeOrdered = By.xpath("//span[text()='Thank you for your purchase!']");
	private final By loadingMask = By.cssSelector(".loading-mask");
	
	public PlaceOrderPage(WebDriver driver) {
		this.driver = driver;
		wait = new WebDriverWait(driver, Duration.ofSeconds(60));
	}
	
	public String getPaymentPageTxt() {
		return wait.until(ExpectedConditions.visibilityOfElementLocated(paymentMethodHeading)).getText();
		
	}
	
	public PlaceOrderPage selectBillingAddressSameAsShippingCheckbox() {
	        try {
	            
	            wait.until(ExpectedConditions.invisibilityOfElementLocated(loadingMask));

	            WebElement checkboxElement = wait.until(ExpectedConditions.presenceOfElementLocated(checkbox));
	            if (checkboxElement.isDisplayed() && !checkboxElement.isSelected()) {
	                checkboxElement.click();
	            }
	        } catch (TimeoutException e) {
	            System.out.println("Checkbox for 'My billing and shipping address are the same' is not present.");
	        } catch (ElementClickInterceptedException e) {
	            System.out.println("Element is not clickable. It may be covered by another element.");
	        }
	        return this;
	    }
	
	public PlaceOrderPage clickOnPlaceOrder() {
		wait.until(ExpectedConditions.visibilityOfElementLocated(placeOrder)).click();
		return new PlaceOrderPage(driver);
	}
	
	public String getOrderedPageTxt() {
		return wait.until(ExpectedConditions.visibilityOfElementLocated(placeOrdered)).getText();
		
	}

}
