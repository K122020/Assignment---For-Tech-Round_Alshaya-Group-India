package org.alshaya.pages;

import java.time.Duration;

import org.alshaya.builderPages.Checkout;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class CartPage {
	
	private WebDriver driver;
	WebDriverWait wait;

	private final By proceedToCheckout = By.xpath("//*[@title='Proceed to Checkout']");
	private final By successMsg = By.xpath("//div[@data-ui-id='message-success']");
	

	public CartPage(WebDriver driver) {
		this.driver = driver;
		wait = new WebDriverWait(driver, Duration.ofSeconds(60));
	}

	public CheckoutPage clickOnCheckout() {
		wait.until(ExpectedConditions.visibilityOfElementLocated(proceedToCheckout)).click();
		
		return new CheckoutPage(driver);
	}

	
	

}
