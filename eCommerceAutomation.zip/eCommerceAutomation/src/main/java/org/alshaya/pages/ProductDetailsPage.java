package org.alshaya.pages;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ProductDetailsPage {
	
	private WebDriver driver;
	WebDriverWait wait;

	private final By addtoCart = By.xpath("//button[@title='Add to Cart']");
	private final By successMsg = By.xpath("//div[@data-ui-id='message-success']");
	private final By cartIcon = By.xpath("(//*[@class='counter qty'])[1]");

	public ProductDetailsPage(WebDriver driver) {
		this.driver = driver;
		wait = new WebDriverWait(driver, Duration.ofSeconds(60));
	}

	
	
	
	public ProductDetailsPage clickOnAddtoCart() {
		
		driver.findElement(addtoCart).click();
		return new ProductDetailsPage(driver);
		
	}
	
	public String successMsg() {
		return wait.until(ExpectedConditions.visibilityOfElementLocated(successMsg)).getText();
	}
	
	public CartPage clickOnCartPage()
	{
		wait.until(ExpectedConditions.visibilityOfElementLocated(cartIcon)).click();
		return new CartPage(driver);
	}

}
