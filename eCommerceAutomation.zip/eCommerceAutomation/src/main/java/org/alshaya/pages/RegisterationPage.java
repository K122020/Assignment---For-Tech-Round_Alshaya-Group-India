package org.alshaya.pages;

import org.alshaya.builderPages.Register;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class RegisterationPage {
	private WebDriver driver;
	
	private final By firstName = By.id("firstname");
	private final By lastName = By.id("lastname");
	private final By email = By.id("email_address");
	private final By password = By.id("password");
	private final By confirmPassword = By.id("password-confirmation");
	private final By createAnAccountBttn = By.xpath("//button[@title='Create an Account']");
	
	
	
	public RegisterationPage(WebDriver driver) {
		this.driver = driver;
	}
	
	public RegisterationPage userRegisteration(Register register) {
		
		driver.findElement(firstName).sendKeys(register.getFirstName());
		driver.findElement(lastName).sendKeys(register.getLastName());
		driver.findElement(email).sendKeys(register.getEmail());
		driver.findElement(password).sendKeys(register.getPassword());
		driver.findElement(confirmPassword).sendKeys(register.getConfirmPassword());
		
		return new RegisterationPage(driver);
	}
	
	public AccountPage submitBttn() {
		driver.findElement(createAnAccountBttn).click();
		return new AccountPage(driver);
	}

}
