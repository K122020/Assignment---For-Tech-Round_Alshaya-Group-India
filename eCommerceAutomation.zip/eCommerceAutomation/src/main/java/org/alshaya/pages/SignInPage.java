package org.alshaya.pages;

import java.time.Duration;

import org.alshaya.builderPages.SignIn;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class SignInPage {

	private WebDriver driver;
	WebDriverWait wait;

	private final By email = By.id("email");
	private final By password = By.id("pass");
	private final By signInBttn = By.id("send2");
	private final By customerLoginHeading = By.xpath("//span[contains(text(),'Customer Login')]");
	private final By successMsgForSignOut = By.xpath("//*[@data-ui-id='page-title-wrapper']");
	
	
	public SignInPage(WebDriver driver) {
		this.driver = driver;
		wait = new WebDriverWait(driver, Duration.ofSeconds(60));
	}
	
	public String validateLoginPageVisibility() {
		return wait.until(ExpectedConditions.visibilityOfElementLocated(customerLoginHeading)).getText();
	}
	
	public Boolean validateInvisibilitySignOut() {
		
		return wait.until(ExpectedConditions.invisibilityOfElementLocated(successMsgForSignOut));
	}
	
	public SignInPage userLogin(SignIn login) {
		System.out.print("Trying to login");
		driver.findElement(email).sendKeys(login.getEmail());
		driver.findElement(password).sendKeys(login.getPassword());
		
		return new SignInPage(driver);
	}
	
	public AccountPage submitBttn() {
		driver.findElement(signInBttn).click();
		return new AccountPage(driver);
	}

}
