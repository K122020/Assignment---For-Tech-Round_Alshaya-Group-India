package org.alshaya.pages;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;


public class ProductListingPage {

	private WebDriver driver;
	WebDriverWait wait;
	
	private final By listingProduct = By.xpath("(//ol[@class='products list items product-items']/li)[3]");
	private final By productDetailsHeading = By.xpath("//h1");

	public ProductListingPage(WebDriver driver) {
		this.driver = driver;
		wait = new WebDriverWait(driver, Duration.ofSeconds(60));
	}

	public String clickOnProduct(String productName) {
		wait.until(ExpectedConditions.visibilityOfElementLocated(listingProduct)).click();
//		List<WebElement> products = driver
//				.findElements(By.xpath("//ol[@class='products list items product-items']/li"));
//		WebElement prod = products.stream()
//				.filter(product -> product
//						.findElement(By.xpath("//ol[@class='products list items product-items']/li/div/div/strong/a"))
//						.getText().equals(productName))
//				.findFirst().orElse(null);
//	
//		
		

		return wait.until(ExpectedConditions.visibilityOfElementLocated(productDetailsHeading)).getText();
		
	}

}
