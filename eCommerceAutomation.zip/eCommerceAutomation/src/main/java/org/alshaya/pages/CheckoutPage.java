package org.alshaya.pages;

import java.time.Duration;

import org.alshaya.builderPages.Checkout;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class CheckoutPage {
	
	private WebDriver driver;
	WebDriverWait wait;

	private final By checkoutHeading = By.xpath("//*[contains(text(),'Shipping Address')]");
	private final By successMsg = By.xpath("//div[@data-ui-id='message-success']");
	private final By company = By.name("company");
	private final By[] streetAddressLocators = { 
			By.name("street[0]"), 
			By.name("street[1]"),
			By.name("street[2]") 
			};
	private final By city = By.name("city");
	private final By stateProvinance = By.name("region_id");
	private final By zipPostal = By.name("postcode");
	private final By country = By.name("country_id");
	private final By phoneNumber  = By.xpath("//input[@name='telephone']");
	private final By shippingMethods = By.xpath("//td[contains(@id, 'label_method_') and text()='Fixed']");
	private final By continueButton = By.xpath("//button[@data-role='opc-continue' and @type='submit']");
	private final By loadingMask = By.cssSelector(".loading-mask");
	

	public CheckoutPage(WebDriver driver) {
		this.driver = driver;
		wait = new WebDriverWait(driver, Duration.ofSeconds(60));
	}


	public String getHeadingTxt() {
		return wait.until(ExpectedConditions.visibilityOfElementLocated(checkoutHeading)).getText();
		
	}
	
	
	public CheckoutPage userShippingAddress(Checkout checkout) throws InterruptedException {
		String[] addressLines = { 
				checkout.getAddress().getLine1(), 
				checkout.getAddress().getLine2(), 
				checkout.getAddress().getLine3()
			};
		
		WebElement companyInput = wait.until(ExpectedConditions.visibilityOfElementLocated(company));
	    companyInput.sendKeys(checkout.getCompany());

	    for (int i = 0; i < streetAddressLocators.length; i++) {
	        WebElement streetAddressInput = wait.until(ExpectedConditions.visibilityOfElementLocated(streetAddressLocators[i]));
	        streetAddressInput.sendKeys(addressLines[i]);
	    }

	    WebElement cityInput = wait.until(ExpectedConditions.visibilityOfElementLocated(city));
	    cityInput.sendKeys(checkout.getCity());

	    WebElement stateProvinanceElement = wait.until(ExpectedConditions.visibilityOfElementLocated(stateProvinance));
	    new Select(stateProvinanceElement).selectByVisibleText(checkout.getStateProvinance());

	    WebElement zipPostalInput = wait.until(ExpectedConditions.visibilityOfElementLocated(zipPostal));
	    zipPostalInput.sendKeys(String.valueOf(checkout.getZipPostal()));

	    WebElement countryElement = wait.until(ExpectedConditions.visibilityOfElementLocated(country));
	    new Select(countryElement).selectByVisibleText(checkout.getCountry());

	    WebElement phoneNumberInput = wait.until(ExpectedConditions.visibilityOfElementLocated(phoneNumber));
	    phoneNumberInput.sendKeys(String.valueOf(checkout.getPhoneNumber()));

	    WebElement shippingMethodsElement = wait.until(ExpectedConditions.elementToBeClickable(shippingMethods));
	    shippingMethodsElement.click();

	        return new CheckoutPage(driver);
	}
	
	
	
	public PlaceOrderPage goTOReviewPayments() {
		 wait.until(ExpectedConditions.invisibilityOfElementLocated(loadingMask));
	    WebElement nextButtonElement = wait.until(ExpectedConditions.elementToBeClickable(continueButton));
	    ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", nextButtonElement);
	    nextButtonElement.click();
	    
	    return new PlaceOrderPage(driver);
	}



}
