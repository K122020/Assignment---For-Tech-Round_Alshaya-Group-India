package org.alshaya.builderPages;

public class Checkout {
    
    private Address address;
    private String city;
    private String stateProvinance;
    private int zipPostal;
    private String country;
    private int phoneNumber;
    private String company;
    
    private Checkout(CheckoutBuilder checkoutBuilder) {
        this.address = checkoutBuilder.address;
        this.city = checkoutBuilder.city;
        this.stateProvinance = checkoutBuilder.stateProvinance;
        this.zipPostal = checkoutBuilder.zipPostal;
        this.country = checkoutBuilder.country;
        this.phoneNumber = checkoutBuilder.phoneNumber;
        this.company = checkoutBuilder.company;
    }
    
    public Address getAddress() {
        return address;
    }

    public String getCity() {
        return city;
    }

    public String getStateProvinance() {
        return stateProvinance;
    }

    public int getZipPostal() {
        return zipPostal;
    }

    public String getCountry() {
        return country;
    }

    public int getPhoneNumber() {
        return phoneNumber;
    }
    
    public String getCompany() {
        return company;
    }
    
    public static class CheckoutBuilder {
        
        private Address address;
        private String city;
        private String stateProvinance;
        private int zipPostal;
        private String country;
        private int phoneNumber;
        private String company;

        public CheckoutBuilder setAddress(Address address) {
            this.address = address;
            return this;
        }

        public CheckoutBuilder setCity(String city) {
            this.city = city;
            return this;
        }

        public CheckoutBuilder setStateProvinance(String stateProvinance) {
            this.stateProvinance = stateProvinance;
            return this;
        }

        public CheckoutBuilder setZipPostal(int zipPostal) {
            this.zipPostal = zipPostal;
            return this;
        }

        public CheckoutBuilder setCountry(String country) {
            this.country = country;
            return this;
        }

        public CheckoutBuilder setPhoneNumber(int phoneNumber) {
            this.phoneNumber = phoneNumber;
            return this;
        }

        public CheckoutBuilder setCompany(String company) {
            this.company = company;
            return this;
        }

        public Checkout build() {
            return new Checkout(this);
        }

		
    }
}
