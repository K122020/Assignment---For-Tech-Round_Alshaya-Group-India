package org.alshaya.builderPages;

public class SignIn {
	
	private String email;
	private String password;
	
	public SignIn(SignInBuilder signInBuilder) {
		this.email = signInBuilder.email;
		this.password = signInBuilder.password;
	}
	
	public String getEmail() {
		return email;
	}
	
	public String getPassword() {
		return password;
	}
	
	public static class SignInBuilder{
		
		private String email;
		private String password;
		
		
		public SignInBuilder setEmail(String email) {
			this.email = email;
			return this;
		}
		public SignInBuilder setPassword(String password) {
			this.password = password;
			return this;
		}
		
		
		public SignIn build() {
			return new SignIn(this);
		}
		
		
	}
	

}
