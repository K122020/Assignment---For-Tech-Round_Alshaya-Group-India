package org.alshaya.tests;

import java.time.Duration;
import java.util.Random;

import org.alshaya.base.BaseTest;
import org.alshaya.base.WebDriverManager;
import org.alshaya.builderPages.Register;
import org.alshaya.pages.AccountPage;
import org.alshaya.pages.HomePage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;


public class RegistrationTest extends BaseTest{
	

	HomePage homePage;
	AccountPage accountPage;
	String expectedRegistration = "Thank you for registering with Main Website Store.";
	String expectedSignOut = "You are signed out";
	String email;
	String actual;
	
	
	
	@Test(priority=1)
	public void createAnAccount() throws InterruptedException {
		driver.get("https://magento.softwaretestingboard.com/customer/account/");
		
        Random random = new Random();
        int randomNumber = random.nextInt(9999);
        email = "gauravDangri" + randomNumber + "@gmail.com";
    	
		Register register = new Register.RegisterBuilder()
					.setFirstName("Gaurav")
					.setLastName("Test")
					.setEmail(email)
					.setPassword("admin@123")
					.setConfirmPassword("admin@123")
					.build();
		
		homePage = new HomePage(driver);
		actual = homePage.clickOnCreateAnAccountMenuOption()
				.userRegisteration(register)
				.submitBttn()
				.checkSuccessMessage();
		
		Assert.assertEquals(actual, expectedRegistration);
		
		
	}
	
	@Test(priority=2)
	public void signUp() {
		accountPage = new AccountPage(driver);
		String actualResult = accountPage.clickOndropDownOption().clickOnSingOutOption().validateSignOut();
		Assert.assertEquals(actualResult, expectedSignOut);
	}

	
	
}
