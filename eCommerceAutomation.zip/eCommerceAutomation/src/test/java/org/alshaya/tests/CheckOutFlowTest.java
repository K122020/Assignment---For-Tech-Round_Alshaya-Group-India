package org.alshaya.tests;
import java.util.Map;
import java.util.Random;
import org.alshaya.base.BaseTest;
import org.alshaya.builderPages.Address;
import org.alshaya.builderPages.Checkout;
import org.alshaya.builderPages.Register;
import org.alshaya.builderPages.SignIn;
import org.alshaya.pages.AccountPage;
import org.alshaya.pages.CartPage;
import org.alshaya.pages.CheckoutPage;
import org.alshaya.pages.HomePage;
import org.alshaya.pages.PlaceOrderPage;
import org.alshaya.pages.ProductDetailsPage;
import org.alshaya.pages.ProductListingPage;
import org.alshaya.pages.SignInPage;
import org.alshaya.utils.TestDataUtils;
import org.testng.Assert;
import org.testng.annotations.Test;


public class CheckOutFlowTest extends BaseTest {
	
	
	HomePage homePage;
	AccountPage accountPage;
	String expectedHeading = "My Account";
	Map<String, Object> testData;
	static String email;
	String actualHeading;
	String expectedRegistration = "Thank you for registering with Main Website Store.";
	String expectedSignOut = "You are signed out";
	String actualRegistration;
	String productName = "Driven Backpack";
	String actualProductName;

	
	

	
	
	@SuppressWarnings("unchecked")
	@Test(priority=1)
	public void createAnAccount() throws InterruptedException {
		driver.get("https://magento.softwaretestingboard.com/customer/account/");
		
        Random random = new Random();
        int randomNumber = random.nextInt(9999);
        email = "gauravDangri" + randomNumber + "@gmail.com";
    	System.out.println(email);
    	testData = TestDataUtils.readTestData("testData.json", Map.class);
		Register register = new Register.RegisterBuilder()
					.setFirstName((String) testData.get("firstName"))
					.setLastName((String) testData.get("lastName"))
					.setEmail(email)
					.setPassword((String) testData.get("password"))
					.setConfirmPassword((String) testData.get("confirmPassword"))
					.build();
		
		homePage = new HomePage(driver);
		actualRegistration = homePage.clickOnCreateAnAccountMenuOption()
				.userRegisteration(register)
				.submitBttn()
				.checkSuccessMessage();
		
		Assert.assertEquals(actualRegistration, expectedRegistration);
		
		accountPage = new AccountPage(driver);
		String actualResult = accountPage.clickOndropDownOption().clickOnSingOutOption().validateSignOut();
		Assert.assertEquals(actualResult, expectedSignOut);
		
		
	}

	
	@SuppressWarnings("unchecked")
	@Test(priority=2)
	public void loginIn() throws InterruptedException {
	SignInPage signInPage = new SignInPage(driver);
		
		HomePage homePage = new HomePage(driver);
		//homePage.clickOnSignInMenuOption();
		
		
		String actualCustomerLogin = homePage.clickOnSignInMenuOption().validateLoginPageVisibility();
		String expectedCustomerLogin = "Customer Login";
		Assert.assertEquals(actualCustomerLogin, expectedCustomerLogin);
		
		System.out.println(email);
		testData = TestDataUtils.readTestData("testData.json", Map.class);
		
		SignIn login = new SignIn.SignInBuilder()
					.setEmail(email)
					.setPassword((String) testData.get("password"))
					.build();
		
		
		actualHeading = signInPage.userLogin(login)
				.submitBttn()
				.validatreAccountHeading();
		
		Assert.assertEquals(actualHeading, expectedHeading);
	}
	
	@SuppressWarnings("unchecked")
	@Test(priority=3)
	public void placeAnOrder() throws InterruptedException {
		String expected = "You added " + productName + " to your shopping cart.";
	    String expectedHeading = "Shipping Address";
	    String expectedPaymentPage = "Payment Method";
	    String expectedOrderedPage = "Thank you for your purchase!";
	    

	    HomePage homepage = new HomePage(driver);
	    homepage.clickOnMainMenu();
	    homepage.clickOnCategory();

	    ProductListingPage plp = new ProductListingPage(driver);
	    actualProductName = plp.clickOnProduct(productName);
	    Assert.assertEquals(actualProductName, productName);

	    ProductDetailsPage pdp = new ProductDetailsPage(driver);
	    String result = pdp.clickOnAddtoCart().successMsg();
	    Assert.assertEquals(result.trim(), expected);
	    testData = TestDataUtils.readTestData("testData.json", Map.class);
	    pdp.clickOnCartPage();
	    Address address = new Address("123 Main St", "Apt 4B", "Floor 3");
	    Checkout checkout = new Checkout.CheckoutBuilder()
	            .setCompany((String) testData.get("company"))
	            .setAddress(address)
	            .setCity((String) testData.get("city"))
	            .setStateProvinance((String) testData.get("stateProvinance"))
	            .setZipPostal(90048)
	            .setCountry((String) testData.get("country"))
	            .setPhoneNumber(1234567890)
	            .build();
	    
	    CartPage cP = new CartPage(driver);
	    String verifyHeading = cP.clickOnCheckout().userShippingAddress(checkout).getHeadingTxt();
	    Assert.assertEquals(verifyHeading.trim(), expectedHeading);
	    
	    CheckoutPage checkoutPage= new CheckoutPage(driver);
	    String verifyPaymentPage = checkoutPage.goTOReviewPayments().getPaymentPageTxt();
	    Assert.assertEquals(verifyPaymentPage.trim(), expectedPaymentPage);
	    
	    PlaceOrderPage placeOrder = new PlaceOrderPage(driver);
	    String verifyOderedtPage = placeOrder.selectBillingAddressSameAsShippingCheckbox().clickOnPlaceOrder().getOrderedPageTxt();
	    Assert.assertEquals(verifyOderedtPage.trim(), expectedOrderedPage);
		
		
	}
	
	@Test(priority=4)
	public void signUp() {
		accountPage = new AccountPage(driver);
		String actualResult = accountPage.clickOndropDownOption().clickOnSingOutOption().validateSignOut();
		Assert.assertEquals(actualResult, expectedSignOut);
	}
	
   
	
	
}
