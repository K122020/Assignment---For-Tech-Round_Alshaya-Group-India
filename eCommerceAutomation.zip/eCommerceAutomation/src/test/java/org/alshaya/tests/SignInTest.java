package org.alshaya.tests;

import java.time.Duration;
import java.util.Random;

import org.alshaya.base.BaseTest;
import org.alshaya.base.WebDriverManager;
import org.alshaya.builderPages.Register;
import org.alshaya.builderPages.SignIn;
import org.alshaya.pages.AccountPage;
import org.alshaya.pages.HomePage;
import org.alshaya.pages.SignInPage;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;


public class SignInTest extends BaseTest{
	
	
	HomePage homePage;
	AccountPage accountPage;
	String expectedHeading = "My Account";
	String expectedSignOut = "You are signed out";
	String email;
	String actualHeading;
	
	
	
	@Test(priority=1)
	public void loginIn() throws InterruptedException {
		driver.get("https://magento.softwaretestingboard.com/customer/account/");
		
        email = "gauravDangri@gmail.com";
    	
		SignIn login = new SignIn.SignInBuilder()
					.setEmail(email)
					.setPassword("admin@123")
					.build();
		
		SignInPage signInPage = new SignInPage(driver);
		actualHeading = signInPage.userLogin(login)
				.submitBttn()
				.validatreAccountHeading();
		
		Assert.assertEquals(actualHeading, expectedHeading);
	}
	
	@Test(priority=3)
	public void signUp() {
		accountPage = new AccountPage(driver);
		String actualResult = accountPage.clickOndropDownOption().clickOnSingOutOption().validateSignOut();
		Assert.assertEquals(actualResult, expectedSignOut);
	}

	
	
	
}
