package org.alshaya.utils;

import java.io.IOException;
import java.io.File;
import com.fasterxml.jackson.databind.ObjectMapper;

public class TestDataUtils {
	
	
	    public static <T> T readTestData(String fileName, Class<T> type) {
	        ObjectMapper objectMapper = new ObjectMapper();
	        try {
	            return objectMapper.readValue(new File("src//test//resources//testdata//" + fileName), type);
	        } catch (IOException e) {
	            throw new RuntimeException("Failed to read test data", e);
	        }
	    }

}
